// lib/firebase_options.dart

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show kIsWeb;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }

    throw UnsupportedError(
      'DefaultFirebaseOptions are not supported for this platform.',
    );
  }

  static const FirebaseOptions web = FirebaseOptions(
      apiKey: "AIzaSyBI6SbtbjG-a67tWMstAE60VgNWqnhNbEA",
      authDomain: "chatappflutter-27051.firebaseapp.com",
      projectId: "chatappflutter-27051",
      storageBucket: "chatappflutter-27051.firebasestorage.app",
      messagingSenderId: "637656502396",
      appId: "1:637656502396:web:6f28ef2d06283928c3f9f9",
      measurementId: "G-MSLD8M2S8V"
  );
}
